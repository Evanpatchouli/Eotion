param([Parameter(Mandatory=$true)][ValidateSet('web','domain','contracts','sdk','storage')][string]$Unit)
$ErrorActionPreference = 'Stop'
$repo = 'C:\Users\31250\Work\Eotion'
$root = Join-Path $env:TEMP 'Eotion-P10.4-backend-uuid'
$instance = Get-Content -Raw (Join-Path $root 'mongo-instance.json') | ConvertFrom-Json
$port = $instance.port
$set = $instance.replSet
$rand = [guid]::NewGuid().ToString('N')
$testUri = "mongodb://127.0.0.1:$port/eotion_p104_test_$rand?directConnection=true&replicaSet=$set"
$mongoUri = "mongodb://127.0.0.1:$port/eotion_p104_app_$rand?directConnection=true&replicaSet=$set"
$tasks = @{
  web = @{ command='pnpm build:web'; exe=(Get-Command pnpm).Source; args=@('build:web') }
  domain = @{ command='pnpm --filter @eotion/domain test'; exe=(Get-Command pnpm).Source; args=@('--filter','@eotion/domain','test') }
  contracts = @{ command='pnpm --filter @eotion/contracts test'; exe=(Get-Command pnpm).Source; args=@('--filter','@eotion/contracts','test') }
  sdk = @{ command='pnpm --filter @eotion/sdk test'; exe=(Get-Command pnpm).Source; args=@('--filter','@eotion/sdk','test') }
  storage = @{ command='pnpm --filter @eotion/storage test'; exe=(Get-Command pnpm).Source; args=@('--filter','@eotion/storage','test') }
}
$task = $tasks[$Unit]
$dir = Join-Path $root $Unit
New-Item -ItemType Directory -Force -Path $dir | Out-Null
function Get-SourceHash {
  Push-Location $repo
  try {
    $tracked = git ls-files
    $selected = $tracked | Where-Object {
      $_ -match '^apps/web/src/' -or $_ -eq 'apps/web/scripts/generate-sw.mjs' -or
      $_ -match '^packages/(domain|contracts|sdk|storage)/src/' -or
      $_ -match '^apps/web/(package\.json|tsconfig[^/]*\.json|vite\.config\.[^/]+)$' -or
      $_ -match '^packages/(domain|contracts|sdk|storage)/(package\.json|tsconfig[^/]*\.json)$'
    } | Sort-Object
    $rows = foreach ($path in $selected) {
      $hash = (Get-FileHash -LiteralPath (Join-Path $repo ($path -replace '/', '\')) -Algorithm SHA256).Hash.ToLowerInvariant()
      [pscustomobject]@{ path=$path; sha256=$hash }
    }
    $canonical = ($rows | ForEach-Object { "$($_.path)`t$($_.sha256)" }) -join "`n"
    $bytes = [Text.Encoding]::UTF8.GetBytes($canonical)
    $sha = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant()
    return @{ sha256=$sha; files=@($rows) }
  } finally { Pop-Location }
}
$before = Get-SourceHash
$started = [DateTime]::UtcNow
$stdout = Join-Path $dir 'stdout.log'
$stderr = Join-Path $dir 'stderr.log'
$info = [System.Diagnostics.ProcessStartInfo]::new()
$info.FileName = $task.exe
$info.WorkingDirectory = $repo
$info.UseShellExecute = $false
$info.RedirectStandardOutput = $true
$info.RedirectStandardError = $true
foreach ($arg in $task.args) { [void]$info.ArgumentList.Add($arg) }
$info.Environment['P4_TEST_MONGODB_URI'] = $testUri
$info.Environment['MONGODB_URI'] = $mongoUri
$info.Environment['CI'] = '1'
$p = [System.Diagnostics.Process]::new()
$p.StartInfo = $info
if (-not $p.Start()) { throw "Unable to start $($task.command)" }
$procId = $p.Id
$birth = (Get-Process -Id $procId).StartTime.ToUniversalTime().ToString('o')
$stdoutTask = $p.StandardOutput.ReadToEndAsync()
$stderrTask = $p.StandardError.ReadToEndAsync()
$p.WaitForExit()
$stdoutText = $stdoutTask.GetAwaiter().GetResult()
$stderrText = $stderrTask.GetAwaiter().GetResult()
[IO.File]::WriteAllText($stdout, $stdoutText, [Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText($stderr, $stderrText, [Text.UTF8Encoding]::new($false))
$ended = [DateTime]::UtcNow
$after = Get-SourceHash
$summary = [ordered]@{
  unit=$Unit; command=$task.command; executable=$task.exe; args=$task.args; cwd=$repo
  startedUtc=$started.ToString('o'); endedUtc=$ended.ToString('o'); elapsedSeconds=[math]::Round(($ended-$started).TotalSeconds,3)
  pnpmVersion='10.34.2'; nodeVersion='v24.22.0'; exitCode=$p.ExitCode
  p4TestMongoUri=$testUri; mongoUri=$mongoUri; mongoInstance=(Join-Path $root 'mongo-instance.json')
  sourceSha256Before=$before.sha256; sourceSha256After=$after.sha256; sourceHashesMatch=($before.sha256 -eq $after.sha256)
  sourceFilesBefore=$before.files; sourceFilesAfter=$after.files
  stdout=$stdout; stderr=$stderr
  testSummary=([regex]::Matches($stdoutText, '(?im)^# (tests|pass|fail|cancelled|skipped)\s+.*$').Value)
}
$summary | ConvertTo-Json -Depth 6 | Set-Content -Encoding utf8 (Join-Path $dir 'result.json')
[pscustomobject]@{unit=$Unit; command=$task.command; exitCode=$p.ExitCode; elapsedSeconds=$summary.elapsedSeconds; sourceHashesMatch=$summary.sourceHashesMatch; stdout=$stdout; stderr=$stderr; result=(Join-Path $dir 'result.json')} | ConvertTo-Json -Depth 3


