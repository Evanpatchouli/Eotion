param([Parameter(Mandatory=$true)][ValidateSet('typecheck','build','domain','http','mcp','performance','version','diff')][string]$Unit)
$ErrorActionPreference = 'Stop'
$repo = 'C:\Users\31250\Work\Eotion'
$root = Join-Path $env:TEMP 'Eotion-P10.4-backend-uuid'
$instance = Get-Content -Raw (Join-Path $root 'mongo-instance.json') | ConvertFrom-Json
$port = $instance.port; $set = $instance.replSet
$rand = [guid]::NewGuid().ToString('N')
$testUri = ("mongodb://127.0.0.1:" + $port + "/eotion_p104_test_" + $rand + "?directConnection=true&replicaSet=" + $set)
$mongoUri = ("mongodb://127.0.0.1:" + $port + "/eotion_p104_app_" + $rand + "?directConnection=true&replicaSet=" + $set)
$pnpm = (Get-Command pnpm).Source
$git = (Get-Command git).Source
$tasks = @{
  typecheck = @{ command='pnpm typecheck'; exe=$pnpm; args=@('typecheck') }
  build = @{ command='pnpm build:api'; exe=$pnpm; args=@('build:api') }
  domain = @{ command='pnpm --filter @eotion/api test:domain'; exe=$pnpm; args=@('--filter','@eotion/api','test:domain') }
  http = @{ command='pnpm --filter @eotion/api test:http'; exe=$pnpm; args=@('--filter','@eotion/api','test:http') }
  mcp = @{ command='pnpm --filter @eotion/api test:mcp'; exe=$pnpm; args=@('--filter','@eotion/api','test:mcp') }
  performance = @{ command='pnpm --filter @eotion/api test:database:performance'; exe=$pnpm; args=@('--filter','@eotion/api','test:database:performance') }
  version = @{ command='pnpm version:check'; exe=$pnpm; args=@('version:check') }
  diff = @{ command='git diff --check'; exe=$git; args=@('diff','--check') }
}
$task = $tasks[$Unit]
$finalRoot = Join-Path $root 'api-final-r2'
$dir = Join-Path $finalRoot $Unit
New-Item -ItemType Directory -Force -Path $dir | Out-Null
function Get-SourceHash {
  Push-Location $repo
  try {
    $tracked = git ls-files
    $selected = $tracked | Where-Object { $_ -match '^apps/api/src/' -or $_ -match '^apps/api/(package\.json|tsconfig[^/]*\.json)$' } | Sort-Object
    $rows = foreach ($path in $selected) {
      $hash = (Get-FileHash -LiteralPath (Join-Path $repo ($path -replace '/', '\')) -Algorithm SHA256).Hash.ToLowerInvariant()
      [pscustomobject]@{ path=$path; sha256=$hash }
    }
    $canonical = ($rows | ForEach-Object { "$($_.path)`t$($_.sha256)" }) -join "`n"
    $sha = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($canonical))).ToLowerInvariant()
    return @{ sha256=$sha; files=@($rows) }
  } finally { Pop-Location }
}
$before = Get-SourceHash
$started = [DateTime]::UtcNow
$stdout = Join-Path $dir 'stdout.log'; $stderr = Join-Path $dir 'stderr.log'
$info = [System.Diagnostics.ProcessStartInfo]::new()
$info.FileName = $task.exe; $info.WorkingDirectory = $repo; $info.UseShellExecute = $false
$info.RedirectStandardOutput = $true; $info.RedirectStandardError = $true
foreach ($arg in $task.args) { [void]$info.ArgumentList.Add($arg) }
$info.Environment['P4_TEST_MONGODB_URI'] = $testUri
$info.Environment['MONGODB_URI'] = $mongoUri
$info.Environment['CI'] = '1'
$p = [System.Diagnostics.Process]::new(); $p.StartInfo = $info
if (-not $p.Start()) { throw "Unable to start $($task.command)" }
$procId = $p.Id; $birth = (Get-Process -Id $procId).StartTime.ToUniversalTime().ToString('o')
$outTask = $p.StandardOutput.ReadToEndAsync(); $errTask = $p.StandardError.ReadToEndAsync(); $p.WaitForExit()
$outText = $outTask.GetAwaiter().GetResult(); $errText = $errTask.GetAwaiter().GetResult()
[IO.File]::WriteAllText($stdout,$outText,[Text.UTF8Encoding]::new($false)); [IO.File]::WriteAllText($stderr,$errText,[Text.UTF8Encoding]::new($false))
$ended = [DateTime]::UtcNow; $after = Get-SourceHash
$stats = @{}
foreach ($name in @('tests','suites','pass','fail','cancelled','skipped','todo')) {
  $m = [regex]::Match($outText, "(?im)^[^\r\n]*\b$name\s+(\d+)\s*$")
  if ($m.Success) { $stats[$name] = [int]$m.Groups[1].Value }
}
$summary = [ordered]@{
  unit=$Unit; command=$task.command; executable=$task.exe; args=$task.args; cwd=$repo
  startedUtc=$started.ToString('o'); endedUtc=$ended.ToString('o'); elapsedSeconds=[math]::Round(($ended-$started).TotalSeconds,3)
  pnpmVersion='10.34.2'; nodeVersion='v24.22.0'; exitCode=$p.ExitCode; processId=$procId; processStartedAtUtc=$birth
  p4TestMongoUri=$testUri; mongoUri=$mongoUri; mongoInstance=(Join-Path $root 'mongo-instance.json')
  sourceSha256Before=$before.sha256; sourceSha256After=$after.sha256; sourceHashesMatch=($before.sha256 -eq $after.sha256)
  sourceFilesBefore=$before.files; sourceFilesAfter=$after.files; testSummary=$stats
  stdout=$stdout; stderr=$stderr
}
$summary | ConvertTo-Json -Depth 7 | Set-Content -Encoding utf8 (Join-Path $dir 'result.json')
[pscustomobject]@{unit=$Unit; command=$task.command; exitCode=$p.ExitCode; elapsedSeconds=$summary.elapsedSeconds; sourceHashesMatch=$summary.sourceHashesMatch; testSummary=$stats; stdout=$stdout; stderr=$stderr; result=(Join-Path $dir 'result.json')} | ConvertTo-Json -Depth 4




