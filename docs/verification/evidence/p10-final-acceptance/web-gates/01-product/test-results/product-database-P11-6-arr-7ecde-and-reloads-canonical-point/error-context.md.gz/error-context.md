# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: product-database.spec.ts >> P11.6 arrange persists one native Date CAS and reloads canonical point
- Location: tests\product-database.spec.ts:12386:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('#database-block-p114b-depends-on-block').getByTestId('database-timeline')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('#database-block-p114b-depends-on-block').getByTestId('database-timeline') with timeout 5000ms
  - waiting for locator('#database-block-p114b-depends-on-block').getByTestId('database-timeline')

```

```yaml
- complementary "工作区导航":
  - strong: Eotion
  - text: Database user database@example.com
  - button "收起侧边栏"
  - text: 工作区 Database workspace
  - button "切换工作区"
  - text: 页面
  - button "新建根页面"
  - tree "页面树":
    - treeitem "展开Database references的子项 Database references 页面操作：Database references" [level=1] [selected]:
      - button "展开Database references的子项"
      - button "Database references"
      - button "页面操作：Database references"
  - button "设置"
  - button "退出登录"
- main:
  - text: Database workspace / Database references
  - status: 已同步
  - article:
    - paragraph: Database workspace
    - heading "Database references" [level=1]
    - region "Tiptap 编辑器":
      - button "选择图片附件"
      - button "选择文件附件"
      - textbox "页面正文编辑区域":
        - button "在数据库区块下方插入区块"
        - button "拖动区块"
        - strong: Root projects
        - button "切换视图": Fallback table
        - button "数据库设置"
        - button "新建记录"
        - region "数据库记录":
          - table:
            - rowgroup:
              - row "名称 属性设置 名称 Notes 属性设置 Notes Points 属性设置 Points Done 属性设置 Done Status 属性设置 Status Due 属性设置 Due Dependencies 属性设置 Dependencies":
                - columnheader "名称 属性设置 名称":
                  - text: 名称
                  - button "属性设置 名称"
                - columnheader "Notes 属性设置 Notes":
                  - text: Notes
                  - button "属性设置 Notes"
                - columnheader "Points 属性设置 Points":
                  - text: Points
                  - button "属性设置 Points"
                - columnheader "Done 属性设置 Done":
                  - text: Done
                  - button "属性设置 Done"
                - columnheader "Status 属性设置 Status":
                  - text: Status
                  - button "属性设置 Status"
                - columnheader "Due 属性设置 Due":
                  - text: Due
                  - button "属性设置 Due"
                - columnheader "Dependencies 属性设置 Dependencies":
                  - text: Dependencies
                  - button "属性设置 Dependencies"
            - rowgroup:
              - row "编辑名称：Child 打开记录：Child 编辑Due：2026-10-14 编辑关联 Dependencies":
                - cell "编辑名称：Child 打开记录：Child":
                  - button "编辑名称：Child": Child
                  - button "打开记录：Child"
                - cell:
                  - button
                - cell:
                  - button
                - cell:
                  - button
                - cell:
                  - button
                - cell "编辑Due：2026-10-14":
                  - button "编辑Due：2026-10-14": 2026-10-14
                - cell "编辑关联 Dependencies":
                  - button "编辑关联 Dependencies"
              - row "编辑名称：Unplanned 打开记录：Unplanned 编辑Due：2032-06-01 编辑关联 Dependencies":
                - cell "编辑名称：Unplanned 打开记录：Unplanned":
                  - button "编辑名称：Unplanned": Unplanned
                  - button "打开记录：Unplanned"
                - cell:
                  - button
                - cell:
                  - button
                - cell:
                  - button
                - cell:
                  - button
                - cell "编辑Due：2032-06-01":
                  - button "编辑Due：2032-06-01": 2032-06-01
                - cell "编辑关联 Dependencies":
                  - button "编辑关联 Dependencies"
              - row "编辑名称：Invalid 打开记录：Invalid 编辑Due：bad-date 编辑关联 Dependencies":
                - cell "编辑名称：Invalid 打开记录：Invalid":
                  - button "编辑名称：Invalid": Invalid
                  - button "打开记录：Invalid"
                - cell:
                  - button
                - cell:
                  - button
                - cell:
                  - button
                - cell:
                  - button
                - cell "编辑Due：bad-date":
                  - button "编辑Due：bad-date": bad-date
                - cell "编辑关联 Dependencies":
                  - button "编辑关联 Dependencies"
              - row "编辑名称：Second unplanned 打开记录：Second unplanned 编辑Due：2032-06-02 编辑关联 Dependencies":
                - cell "编辑名称：Second unplanned 打开记录：Second unplanned":
                  - button "编辑名称：Second unplanned": Second unplanned
                  - button "打开记录：Second unplanned"
                - cell:
                  - button
                - cell:
                  - button
                - cell:
                  - button
                - cell:
                  - button
                - cell "编辑Due：2032-06-02":
                  - button "编辑Due：2032-06-02": 2032-06-02
                - cell "编辑关联 Dependencies":
                  - button "编辑关联 Dependencies"
        - button "在区块下方插入区块"
        - button "拖动区块"
        - paragraph
```

# Test source

```ts
  12313 |     expect(handleWidth).toBeLessThanOrEqual(12)
  12314 |     expect(handleHeight).toBeLessThanOrEqual(32)
  12315 |     await dragByTouch(shortBar, 36, true)
  12316 |     await expect(shortBar).toHaveAttribute('data-drag-state', 'idle')
  12317 |     expect(api.requests.filter(request => request.method === 'PATCH' && request.path.endsWith('/cells/root-date'))).toHaveLength(0)
  12318 |     expect(api.records.find(item => item.id === 'p114b-a')?.properties['root-date']).toEqual({ start: '2026-10-13', end: '2026-10-13' })
  12319 | 
  12320 |     await dragByTouch(shortBar, 36)
  12321 |     await expect.poll(() => api.requests.filter(request => request.method === 'PATCH' && request.path.endsWith('/cells/root-date')).length).toBe(1)
  12322 |     await expect.poll(() => api.records.find(item => item.id === 'p114b-a')?.properties['root-date']).toEqual({ start: '2026-10-14', end: '2026-10-14' })
  12323 | 
  12324 |     const pointEnd = timeline.locator('[data-testid="timeline-resize-end"][data-record-id="p114b-b"]')
  12325 |     await expect(pointEnd).toBeVisible()
  12326 |     const pointBounds = await pointEnd.boundingBox()
  12327 |     const scrollerBounds = await timeline.getByTestId('timeline-scroll').boundingBox()
  12328 |     expect(pointBounds).not.toBeNull()
  12329 |     expect(scrollerBounds).not.toBeNull()
  12330 |     expect(pointBounds!.x + pointBounds!.width / 2).toBeGreaterThanOrEqual(scrollerBounds!.x)
  12331 |     expect(pointBounds!.x + pointBounds!.width / 2).toBeLessThanOrEqual(scrollerBounds!.x + scrollerBounds!.width)
  12332 |     await dragByTouch(pointEnd, 36)
  12333 |     await expect.poll(() => api.requests.filter(request => request.method === 'PATCH' && request.path.endsWith('/cells/root-date')).length).toBe(2)
  12334 |     await expect.poll(() => api.records.find(item => item.id === 'p114b-b')?.properties['root-date']).toMatchObject({ start: '2026-10-14', end: '2026-10-14' })
  12335 | 
  12336 |     const edgeBar = timeline.locator('[data-testid="timeline-bar"][data-record-id="p114b-c"]')
  12337 |     const edgeHandle = timeline.locator('[data-testid="timeline-resize-start"][data-record-id="p114b-c"]')
  12338 |     await expect(edgeHandle).toBeVisible()
  12339 |     const edge = await edgeHandle.boundingBox()
  12340 |     expect(edge).not.toBeNull()
  12341 |     expect(edge!.width).toBeLessThanOrEqual(12)
  12342 |     await dragByTouch(edgeHandle, -36, true)
  12343 |     await expect(edgeBar).toHaveAttribute('data-drag-state', 'idle')
  12344 |     expect(api.requests.filter(request => request.method === 'PATCH' && request.path.endsWith('/cells/root-date'))).toHaveLength(2)
  12345 |     expect(api.records.find(item => item.id === 'p114b-c')?.properties['root-date']).toEqual({ start: '2026-10-15', end: '2026-10-16' })
  12346 |     await session.detach()
  12347 |   } finally {
  12348 |     await context.close()
  12349 |   }
  12350 | })
  12351 | // P11.6 explicit empty-cell scheduling shares the frozen Date mutation adapter.
  12352 | async function p116ScheduleFixture(page: Page, options: Parameters<typeof installApi>[2] = {}, active = false) {
  12353 |   return p114bFixture(page, 'depends-on', [
  12354 |     record('p116-empty', rootDatabase.id, 'p116-empty-page', { 'root-title': 'Unplanned', 'root-date': null }),
  12355 |     record('p116-second', rootDatabase.id, 'p116-second-page', { 'root-title': 'Second unplanned' }),
  12356 |     record('p116-invalid', rootDatabase.id, 'p116-invalid-page', { 'root-title': 'Invalid', 'root-date': 'bad-date' }),
  12357 |     record('p116-child', rootDatabase.id, 'p116-child-page', { 'root-title': 'Child', 'root-date': '2026-10-14', 'p114b-depends-on-relation': ['p116-empty'] }),
  12358 |   ], options, active ? 'shift_when_overlapping' : 'no_auto_shift')
  12359 | }
  12360 | 
  12361 | async function p116OpenSchedule(timeline: Locator) {
  12362 |   const details = timeline.locator('details')
  12363 |   if (!(await details.evaluate(element => (element as HTMLDetailsElement).open))) await details.locator('summary').click()
  12364 |   await details.getByRole('button', { name: '安排：Unplanned', exact: true }).click()
  12365 |   return timeline.getByTestId('timeline-schedule-form')
  12366 | }
  12367 | 
  12368 | test('P11.6 arrange explicit date has no default and cancel has zero writes', async ({ page }) => {
  12369 |   const { timeline, api } = await p116ScheduleFixture(page)
  12370 |   const form = await p116OpenSchedule(timeline)
  12371 |   await expect(form.getByLabel('安排日期')).toHaveValue('')
  12372 |   await expect(form.getByLabel('安排日期')).toBeFocused()
  12373 |   await expect(form.getByRole('button', { name: '保存', exact: true })).toBeDisabled()
  12374 |   await form.getByLabel('安排日期').fill('2026-10-20')
  12375 |   await form.getByRole('button', { name: '取消', exact: true }).click()
  12376 |   await expect(form).toHaveCount(0)
  12377 |   await expect(timeline.getByRole('button', { name: '安排：Unplanned', exact: true })).toBeFocused()
  12378 |   await p116OpenSchedule(timeline)
  12379 |   await form.getByLabel('安排日期').press('Escape')
  12380 |   await expect(form).toHaveCount(0)
  12381 |   expect(api.requests.filter(request => request.method === 'PATCH')).toHaveLength(0)
  12382 |   expect(p114cBatchPosts(api)).toHaveLength(0)
  12383 |   expect(api.records.find(item => item.id === 'p116-empty')?.properties['root-date']).toBeNull()
  12384 | })
  12385 | 
  12386 | test('P11.6 arrange persists one native Date CAS and reloads canonical point', async ({ page }) => {
  12387 |   const { timeline, api } = await p116ScheduleFixture(page)
  12388 |   const form = await p116OpenSchedule(timeline)
  12389 |   await form.getByLabel('安排日期').fill('2032-06-01')
  12390 |   await form.getByRole('button', { name: '保存', exact: true }).click()
  12391 |   await expect(form).toHaveCount(0)
  12392 |   const bar = timeline.locator('[data-testid="timeline-bar"][data-record-id="p116-empty"]')
  12393 |   await expect(bar).toBeVisible()
  12394 |   await expect(bar).toBeFocused()
  12395 |   expect(p114bRelationPatch(api, 'root-date')).toHaveLength(1)
  12396 |   expect(p114bRelationPatch(api, 'root-date')[0]?.payload).toMatchObject({ value: '2032-06-01', expectedDatabaseVersion: 1, expectedRecordVersion: 1 })
  12397 |   expect(p114cBatchPosts(api)).toHaveLength(0)
  12398 |   expect(api.records.find(item => item.id === 'p116-empty')?.properties['root-date']).toBe('2032-06-01')
  12399 |   const details = timeline.locator('details')
  12400 |   if (!(await details.evaluate(element => (element as HTMLDetailsElement).open))) await details.locator('summary').click()
  12401 |   const second = details.getByRole('button', { name: '安排：Second unplanned', exact: true })
  12402 |   await expect(second).toBeEnabled()
  12403 |   await second.click()
  12404 |   await form.getByLabel('安排日期').fill('2032-06-02')
  12405 |   await form.getByRole('button', { name: '保存', exact: true }).click()
  12406 |   await expect.poll(() => p114bRelationPatch(api, 'root-date').length).toBe(2)
  12407 |   await expect(form).toHaveCount(0)
  12408 |   const databaseBlock = page.locator('#database-block-p114b-depends-on-block')
  12409 |   await databaseBlock.getByRole('button', { name: '切换视图' }).click()
  12410 |   await page.getByRole('group', { name: '数据库视图', exact: true }).getByRole('button', { name: 'Fallback table', exact: true }).click()
  12411 |   await expect(databaseBlock.locator('tr').filter({ has: page.getByRole('button', { name: '编辑名称：Unplanned', exact: true }) })).toContainText('2032-06-01')
  12412 |   await page.reload()
> 12413 |   await expect(timeline).toBeVisible()
        |                          ^ Error: expect(locator).toBeVisible() failed
  12414 |   await databaseBlock.getByRole('button', { name: '切换视图' }).click()
  12415 |   await page.getByRole('group', { name: '数据库视图', exact: true }).getByRole('button', { name: 'Fallback table', exact: true }).click()
  12416 |   await expect(databaseBlock.locator('tr').filter({ has: page.getByRole('button', { name: '编辑名称：Unplanned', exact: true }) })).toContainText('2032-06-01')
  12417 | })
  12418 | 
  12419 | test('P11.6 arrange active policy uses one atomic batch and canonical downstream dates', async ({ page }) => {
  12420 |   const { timeline, api, timelineView } = await p116ScheduleFixture(page, {}, true)
  12421 |   const form = await p116OpenSchedule(timeline)
  12422 |   await form.getByLabel('安排日期').fill('2026-10-20')
  12423 |   await form.getByRole('button', { name: '保存', exact: true }).click()
  12424 |   await expect(form).toHaveCount(0)
  12425 |   expect(p114cBatchPosts(api)).toHaveLength(1)
  12426 |   expect(p114cBatchPosts(api)[0]?.payload).toMatchObject({ context: { viewId: timelineView.id, expectedViewVersion: 1 }, records: [{ recordId: 'p116-empty', expectedRecordVersion: 1, cells: [{ propertyId: 'root-date', value: '2026-10-20' }] }] })
  12427 |   expect(p114bRelationPatch(api, 'root-date')).toHaveLength(0)
  12428 |   // A point has no exclusive end; the frozen planner moves an overlapping child
  12429 |   // to the same date boundary (ranges retain their exclusive endpoint rule).
  12430 |   expect(api.records.find(item => item.id === 'p116-child')?.properties['root-date']).toBe('2026-10-20')
  12431 | })
  12432 | 
  12433 | for (const outcome of ['conflict', 'uncertain', 'refresh-failure'] as const) {
  12434 |   test(`P11.6 arrange ${outcome} never retries or claims batch success`, async ({ page }) => {
  12435 |     const { timeline, api } = await p116ScheduleFixture(page, outcome === 'conflict'
  12436 |       ? { conflictCellBatchMutations: 1 } : { cellBatchMutationOutcome: 'uncertain' }, true)
  12437 |     const form = await p116OpenSchedule(timeline)
  12438 |     await form.getByLabel('安排日期').fill('2026-10-20')
  12439 |     if (outcome === 'refresh-failure') api.failTableLoads = 1
  12440 |     await form.getByRole('button', { name: '保存', exact: true }).click()
  12441 |     const databaseBlock = page.locator('#database-block-p114b-depends-on-block')
  12442 |     const mutationAlert = databaseBlock.locator(':scope > .eotion-database-error').filter({ hasText: outcome === 'conflict' ? /^相关记录已发生变化，已刷新到最新版本。$/u : /^提交结果暂未确认，请重新加载当前视图。$/u })
  12443 |     await expect(mutationAlert).toHaveCount(1)
  12444 |     expect(p114cBatchPosts(api)).toHaveLength(1)
  12445 |     expect(p114bRelationPatch(api, 'root-date')).toHaveLength(0)
  12446 |     expect(api.records.find(item => item.id === 'p116-empty')?.properties['root-date']).toBeNull()
  12447 |   })
  12448 | }
  12449 | 
  12450 | test('P11.6 arrange rejects stale record capture and offline submit, excludes invalid cells', async ({ page }) => {
  12451 |   const { timeline, api } = await p116ScheduleFixture(page)
  12452 |   let form = await p116OpenSchedule(timeline)
  12453 |   await expect(timeline.getByRole('button', { name: '安排：Invalid', exact: true })).toHaveCount(0)
  12454 |   await form.getByLabel('安排日期').fill('2026-10-20')
  12455 |   await page.context().setOffline(true)
  12456 |   await expect(form.getByRole('button', { name: '保存', exact: true })).toBeDisabled()
  12457 |   await page.context().setOffline(false)
  12458 |   await expect(form.getByRole('button', { name: '保存', exact: true })).toBeEnabled()
  12459 |   api.records.find(item => item.id === 'p116-empty')!.version += 1
  12460 |   await p115RefreshLoadedWindow(timeline)
  12461 |   form = timeline.getByTestId('timeline-schedule-form')
  12462 |   await form.getByRole('button', { name: '保存', exact: true }).click()
  12463 |   expect(p114bRelationPatch(api, 'root-date')).toHaveLength(0)
  12464 | })
  12465 | 
  12466 | for (const width of [390, 360]) {
  12467 |   test.describe(`P11.6 arrange ${width}px coarse context`, () => {
  12468 |   test.use({ viewport: { width, height: 844 }, hasTouch: true, isMobile: true })
  12469 |   test(`P11.6 arrange ${width}px touch form stays inside viewport`, async ({ page }) => {
  12470 |     const { timeline, api } = await p116ScheduleFixture(page)
  12471 |     await page.setViewportSize({ width, height: 844 })
  12472 |     await page.emulateMedia({ reducedMotion: 'reduce' })
  12473 |     expect(await page.evaluate(() => matchMedia('(pointer: coarse)').matches)).toBe(true)
  12474 |     const form = await p116OpenSchedule(timeline)
  12475 |     await form.getByLabel('安排日期').fill('2026-10-20')
  12476 |     for (const control of await form.locator('input, button').all()) {
  12477 |       const bounds = await control.boundingBox()
  12478 |       expect(bounds).not.toBeNull()
  12479 |       expect(bounds!.x).toBeGreaterThanOrEqual(0)
  12480 |       expect(bounds!.x + bounds!.width).toBeLessThanOrEqual(width)
  12481 |       expect(bounds!.height).toBeGreaterThanOrEqual(44)
  12482 |     }
  12483 |     await form.getByRole('button', { name: '取消', exact: true }).tap()
  12484 |     expect(p114bRelationPatch(api, 'root-date')).toHaveLength(0)
  12485 |   })
  12486 |   })
  12487 | }
  12488 | 
  12489 | test('P11.6 arrange configuration and view scope invalidate the captured form; Separate remains read only', async ({ page }) => {
  12490 |   const { timeline, timelineView, api } = await p116ScheduleFixture(page)
  12491 |   let form = await p116OpenSchedule(timeline)
  12492 |   await form.getByLabel('安排日期').fill('2026-10-20')
  12493 |   const canonicalView = api.views.find(item => item.id === timelineView.id)!
  12494 |   const originalConfig = canonicalView.config
  12495 |   canonicalView.config = { ...canonicalView.config, options: { timeline: { scale: 'week', dateSource: { mode: 'start-end', startPropertyId: 'root-date', endPropertyId: 'root-date' } } } }
  12496 |   canonicalView.version += 1
  12497 |   await p115RefreshLoadedWindow(timeline)
  12498 |   await expect(form).toHaveCount(0)
  12499 |   await expect(timeline.getByRole('button', { name: /^安排：/u })).toHaveCount(0)
  12500 |   canonicalView.config = originalConfig
  12501 |   canonicalView.version += 1
  12502 |   await p115RefreshLoadedWindow(timeline)
  12503 |   form = await p116OpenSchedule(timeline)
  12504 |   const databaseBlock = page.locator('#database-block-p114b-depends-on-block')
  12505 |   await databaseBlock.getByRole('button', { name: '切换视图' }).click()
  12506 |   await page.getByRole('group', { name: '数据库视图', exact: true }).getByRole('button', { name: 'Fallback table', exact: true }).click()
  12507 |   await expect(form).toHaveCount(0)
  12508 |   expect(p114bRelationPatch(api, 'root-date')).toHaveLength(0)
  12509 |   expect(p114cBatchPosts(api)).toHaveLength(0)
  12510 | })
  12511 | 
  12512 | 
  12513 | // R2 focus ownership: hold local body loading without changing the original identity case.
```