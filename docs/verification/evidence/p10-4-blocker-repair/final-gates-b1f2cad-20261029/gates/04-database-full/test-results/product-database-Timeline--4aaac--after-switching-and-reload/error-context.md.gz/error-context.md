# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: product-database.spec.ts >> Timeline can be created from a database view selector and keeps its date source and bar after switching and reload
- Location: tests\product-database.spec.ts:3226:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('#database-block-timeline-create-block').getByTestId('database-timeline').getByTestId('timeline-bar')
Expected substring: "Timeline create record"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" locator('#database-block-timeline-create-block').getByTestId('database-timeline').getByTestId('timeline-bar') with timeout 5000ms
  - waiting for locator('#database-block-timeline-create-block').getByTestId('database-timeline').getByTestId('timeline-bar')

```

```yaml
- complementary "工作区导航":
  - strong: Eotion
  - text: Database user database@example.com
  - button "收起侧边栏"
  - text: 工作区 Database workspace
  - button "切换工作区"
  - text: 页面
  - button "新建根页面"
  - tree "页面树":
    - treeitem "展开Database references的子项 Database references 页面操作：Database references" [level=1] [selected]:
      - button "展开Database references的子项"
      - button "Database references"
      - button "页面操作：Database references"
  - button "设置"
  - button "退出登录"
- main:
  - text: Database workspace / Database references
  - status: 已同步
  - article:
    - paragraph: Database workspace
    - heading "Database references" [level=1]
    - region "Tiptap 编辑器":
      - button "选择图片附件"
      - button "选择文件附件"
      - textbox "页面正文编辑区域":
        - button "在数据库区块下方插入区块"
        - button "拖动区块"
        - strong: Root projects
        - button "切换视图": 时间线 1
        - button "数据库设置"
        - button "新建记录"
        - button "上一个时间段"
        - button "今天"
        - button "下一个时间段"
        - combobox "时间轴刻度":
          - option "小时"
          - option "日"
          - option "周"
          - option "双周"
          - option "月" [selected]
          - option "季度"
          - option "年"
        - region "时间轴":
          - button "跳转到Timeline create record的开始日期": ←
        - button "在区块下方插入区块"
        - button "拖动区块"
        - paragraph
```

# Test source

```ts
  3158 |   await expect.poll(() => api.blocks.find(item => item.id === 'view-lifecycle')?.props.node?.attrs).toEqual({ databaseId: rootDatabase.id, viewId: 'view-root-id' })
  3159 | 
  3160 |   expect(api.blocks.filter(item => item.type === 'database' && (item.props.node?.attrs as { viewId?: string } | undefined)?.viewId === 'view-root-id')).toHaveLength(2)
  3161 |   await table.getByRole('button', { name: '切换视图' }).click()
  3162 |   await page.locator('.eotion-database-view-menu').getByRole('button', { name: '删除视图 表格视图' }).click()
  3163 |   await expect.poll(() => api.requests.some(({ method, path }) => method === 'DELETE' && path.endsWith('/views/view-root-id'))).toBe(true)
  3164 |   await expect.poll(() => api.views).toHaveLength(2)
  3165 |   await expect(page.getByRole('alert')).toContainText('仍被其它数据库块引用')
  3166 |   await expect(table.getByRole('button', { name: '切换视图' })).toContainText('Quarterly')
  3167 | 
  3168 |   await tables.nth(1).getByRole('button', { name: '切换视图' }).click()
  3169 |   await page.locator('.eotion-database-view-menu').getByRole('button', { name: 'Quarterly', exact: true }).click()
  3170 |   await expect(tables.nth(1).getByRole('button', { name: '切换视图' })).toContainText('Quarterly')
  3171 |   await tables.nth(1).getByRole('button', { name: '切换视图' }).click()
  3172 |   await page.locator('.eotion-database-view-menu').getByRole('button', { name: /^表格视图/u }).click()
  3173 |   await expect(tables.nth(1).getByRole('button', { name: '切换视图' })).toContainText('表格视图')
  3174 |   await tables.nth(1).getByRole('button', { name: '切换视图' }).click()
  3175 |   const deleteMenu = page.locator('.eotion-database-view-menu')
  3176 |   await deleteMenu.locator('.eotion-database-view-row.is-selected').hover()
  3177 |   await deleteMenu.getByRole('button', { name: '删除视图 表格视图' }).click()
  3178 |   await expect.poll(() => api.views.map(item => item.name)).toEqual(['Quarterly'])
  3179 |   expect(api.requests.some(({ method, path }) => method === 'DELETE' && path.endsWith('/views/view-root-id'))).toBe(true)
  3180 | 
  3181 |   await table.getByRole('button', { name: '切换视图' }).click()
  3182 |   await page.locator('.eotion-database-view-menu').getByRole('button', { name: '新建表格视图' }).click()
  3183 |   await expect(table.getByRole('button', { name: '切换视图' })).toContainText('表格 2')
  3184 |   await table.getByRole('button', { name: '切换视图' }).click()
  3185 |   await page.locator('.eotion-database-view-menu .eotion-database-view-row.is-selected').hover()
  3186 |   await page.locator('.eotion-database-view-menu').getByRole('button', { name: '删除视图 表格 2' }).click()
  3187 |   await expect(table.getByRole('button', { name: '切换视图' })).toContainText('Quarterly')
  3188 |   await expect.poll(() => api.views.map(item => item.name)).toEqual(['Quarterly'])
  3189 |   await expect.poll(() => api.blocks.find(item => item.id === 'view-lifecycle')?.props.node?.attrs).toEqual({ databaseId: rootDatabase.id, viewId: api.views[0]?.id })
  3190 | 
  3191 |   await page.reload()
  3192 |   await expect(page.locator('.eotion-editor-content .eotion-database').nth(0).getByRole('button', { name: '切换视图' })).toContainText('Quarterly')
  3193 |   await page.locator('.eotion-editor-content .eotion-database').nth(0).getByRole('button', { name: '切换视图' }).click()
  3194 |   const lastViewMenu = page.locator('.eotion-database-view-menu')
  3195 |   await expect(lastViewMenu.getByRole('button', { name: '删除视图 Quarterly' })).toBeDisabled()
  3196 | })
  3197 | 
  3198 | test('database view selector creates a List view through the existing DatabaseView API', async ({ page }) => {
  3199 |   const api = await installApi(page, [
  3200 |     block('create-list-view-block', 'database', { type: 'eotionDatabase', attrs: { databaseId: rootDatabase.id, viewId: 'view-root-id' } }, 100),
  3201 |   ], { databases: [rootDatabase], views: [view('view-root-id', rootDatabase.id)], properties: rootProperties, records: [basicRecord] })
  3202 |   api.pages.push({ ...pageRecord, id: basicRecord.pageId, title: 'List record', orderKey: '0000000000000002', role: 'database-record' })
  3203 |   const initialViewCount = api.views.length
  3204 |   await page.goto('/#/app/database-workspace/page/database-page')
  3205 | 
  3206 |   const database = page.locator('#database-block-create-list-view-block')
  3207 |   await expect(database.locator('tbody')).toBeVisible()
  3208 |   await database.getByRole('button', { name: '切换视图' }).click()
  3209 |   const menu = page.locator('.eotion-database-view-menu')
  3210 |   await menu.getByRole('button', { name: '新建列表视图' }).click()
  3211 | 
  3212 |   await expect(database.getByTestId('database-list')).toBeVisible()
  3213 |   await expect.poll(() => api.views).toHaveLength(initialViewCount + 1)
  3214 |   const created = api.views.find(item => item.id !== 'view-root-id')
  3215 |   expect(created?.type).toBe('list')
  3216 |   expect(created?.config).toEqual(DEFAULT_DATABASE_VIEW_CONFIG)
  3217 |   expect(api.requests.some(({ method, path, payload }) => method === 'POST' && path.endsWith(`/databases/${rootDatabase.id}/views`) && payload?.type === 'list' && payload?.config?.filters?.length === 0 && payload?.config?.sorts?.length === 0 && payload?.config?.visibleProperties === null && payload?.config?.propertyOrder === null)).toBe(true)
  3218 |   await expect.poll(() => api.blocks.find(item => item.id === 'create-list-view-block')?.props.node?.attrs).toEqual({ databaseId: rootDatabase.id, viewId: created?.id })
  3219 | 
  3220 |   await database.getByRole('button', { name: '切换视图' }).click()
  3221 |   await menu.getByRole('button', { name: '表格视图', exact: true }).click()
  3222 |   await expect(database.locator('tbody')).toBeVisible()
  3223 |   await expect(database.getByTestId('database-list')).toHaveCount(0)
  3224 | })
  3225 | 
  3226 | test('Timeline can be created from a database view selector and keeps its date source and bar after switching and reload', async ({ page }) => {
  3227 |   const date = property('timeline-create-date', rootDatabase.id, 'Schedule', 'date')
  3228 |   const item = record('timeline-create-record', rootDatabase.id, 'timeline-create-page', {
  3229 |     'root-title': 'Timeline create record', [date.id]: { start: '2026-10-13', end: '2026-10-15' },
  3230 |   })
  3231 |   const api = await installApi(page, [
  3232 |     block('timeline-create-block', 'database', { type: 'eotionDatabase', attrs: { databaseId: rootDatabase.id, viewId: 'view-root-id' } }, 100),
  3233 |   ], { databases: [rootDatabase], views: [view('view-root-id', rootDatabase.id)], properties: [...rootProperties.filter(item => item.id !== 'root-date'), date], records: [item] })
  3234 |   api.pages.push({ ...pageRecord, id: item.pageId, title: 'Timeline create record', role: 'database-record' })
  3235 |   await page.goto('/#/app/database-workspace/page/database-page')
  3236 | 
  3237 |   const database = page.locator('#database-block-timeline-create-block')
  3238 |   const selector = database.getByRole('button', { name: '切换视图' })
  3239 |   await selector.click()
  3240 |   const menu = page.getByRole('group', { name: '数据库视图', exact: true })
  3241 |   await menu.getByRole('button', { name: '新建时间线视图' }).click()
  3242 | 
  3243 |   let dialog = page.getByRole('dialog', { name: '新建时间线视图' })
  3244 |   await expect(dialog).toBeVisible()
  3245 |   await expect(dialog.getByRole('button', { name: '日期来源' })).toHaveAttribute('data-value', 'date-property')
  3246 |   await expect(dialog.getByRole('button', { name: '日期属性', exact: true })).toHaveAttribute('data-value', date.id)
  3247 |   expect(api.requests.filter(({ method, path }) => method === 'POST' && path.endsWith(`/databases/${rootDatabase.id}/views`))).toHaveLength(0)
  3248 |   await page.keyboard.press('Escape')
  3249 |   await expect(dialog).toHaveCount(0)
  3250 |   expect(api.requests.filter(({ method, path }) => method === 'POST' && path.endsWith(`/databases/${rootDatabase.id}/views`))).toHaveLength(0)
  3251 |   await selector.click()
  3252 |   await page.getByRole('group', { name: '数据库视图', exact: true }).getByRole('button', { name: '新建时间线视图' }).click()
  3253 |   dialog = page.getByRole('dialog', { name: '新建时间线视图' })
  3254 |   await page.getByRole('button', { name: '创建时间线' }).click()
  3255 | 
  3256 |   const timeline = database.getByTestId('database-timeline')
  3257 |   await expect(timeline).toBeVisible()
> 3258 |   await expect(timeline.getByTestId('timeline-bar')).toContainText('Timeline create record')
       |                                                      ^ Error: expect(locator).toContainText(expected) failed
  3259 |   const created = api.views.find(item => item.type === 'timeline')!
  3260 |   expect(created.config.options?.timeline?.dateSource).toEqual({ mode: 'date-property', propertyId: date.id })
  3261 |   const createRequests = api.requests.filter(({ method, path }) => method === 'POST' && path.endsWith(`/databases/${rootDatabase.id}/views`))
  3262 |   expect(createRequests).toHaveLength(1)
  3263 |   expect(createRequests[0]?.payload).toMatchObject({ type: 'timeline', config: { options: { timeline: { dateSource: { mode: 'date-property', propertyId: date.id } } } } })
  3264 | 
  3265 |   await selector.click()
  3266 |   await page.getByRole('group', { name: '数据库视图', exact: true }).getByRole('button', { name: '表格视图', exact: true }).click()
  3267 |   await expect(database.locator('tbody')).toBeVisible()
  3268 |   await expect.poll(() => api.blocks.find(item => item.id === 'timeline-create-block')?.props.node?.attrs).toEqual({ databaseId: rootDatabase.id, viewId: 'view-root-id' })
  3269 |   await selector.click()
  3270 |   await page.getByRole('group', { name: '数据库视图', exact: true }).getByRole('button', { name: created.name, exact: true }).click()
  3271 |   await expect(database.getByTestId('timeline-bar')).toContainText('Timeline create record')
  3272 |   await expect.poll(() => api.blocks.find(item => item.id === 'timeline-create-block')?.props.node?.attrs).toEqual({ databaseId: rootDatabase.id, viewId: created.id })
  3273 | 
  3274 |   await page.reload()
  3275 |   const reloadedDatabase = page.locator('#database-block-timeline-create-block')
  3276 |   await expect(reloadedDatabase.getByRole('button', { name: '切换视图' })).toContainText(created.name)
  3277 |   await expect(reloadedDatabase.getByTestId('database-timeline').getByTestId('timeline-bar')).toContainText('Timeline create record')
  3278 |   expect(api.views.find(item => item.id === created.id)?.config.options?.timeline?.dateSource).toEqual({ mode: 'date-property', propertyId: date.id })
  3279 | })
  3280 | 
  3281 | test('Timeline creation adds a Date property first when the database has no Date properties', async ({ page }) => {
  3282 |   const api = await installApi(page, [
  3283 |     block('timeline-create-without-date-block', 'database', { type: 'eotionDatabase', attrs: { databaseId: rootDatabase.id, viewId: 'view-root-id' } }, 100),
  3284 |   ], { databases: [rootDatabase], views: [view('view-root-id', rootDatabase.id)], properties: [rootProperties[0]!], records: [] })
  3285 |   await page.goto('/#/app/database-workspace/page/database-page')
  3286 |   const database = page.locator('#database-block-timeline-create-without-date-block')
  3287 |   await database.getByRole('button', { name: '切换视图' }).click()
  3288 |   await page.getByRole('group', { name: '数据库视图', exact: true }).getByRole('button', { name: '新建时间线视图' }).click()
  3289 | 
  3290 |   const dialog = page.getByRole('dialog', { name: '新建时间线视图' })
  3291 |   await expect(dialog).toContainText('当前数据库没有日期属性')
  3292 |   await expect(page.getByRole('button', { name: '创建时间线' })).toBeDisabled()
  3293 |   await dialog.getByRole('button', { name: '新增日期属性' }).click()
  3294 |   await expect.poll(() => api.properties.filter(item => item.type === 'date')).toHaveLength(1)
  3295 |   const date = api.properties.find(item => item.type === 'date')!
  3296 |   await expect(dialog.getByRole('button', { name: '日期属性', exact: true })).toHaveAttribute('data-value', date.id)
  3297 |   await expect(page.getByRole('button', { name: '创建时间线' })).toBeEnabled()
  3298 |   expect(api.requests.filter(({ method, path }) => method === 'POST' && path.endsWith(`/databases/${rootDatabase.id}/views`))).toHaveLength(0)
  3299 | 
  3300 |   await page.getByRole('button', { name: '创建时间线' }).click()
  3301 |   await expect(database.getByTestId('database-timeline')).toBeVisible()
  3302 |   const created = api.views.find(item => item.type === 'timeline')!
  3303 |   expect(created.config.options?.timeline?.dateSource).toEqual({ mode: 'date-property', propertyId: date.id })
  3304 |   expect(api.requests.filter(({ method, path }) => method === 'POST' && path.endsWith(`/databases/${rootDatabase.id}/views`)).map(item => item.payload?.type)).toEqual(['timeline'])
  3305 | })
  3306 | 
  3307 | test('Timeline create recovers the same pending id when offline closes the dialog during an unknown POST', async ({ page, context }) => {
  3308 |   const date = property('timeline-unknown-date', rootDatabase.id, 'Schedule', 'date')
  3309 |   const api = await installApi(page, [
  3310 |     block('timeline-unknown-block', 'database', { type: 'eotionDatabase', attrs: { databaseId: rootDatabase.id, viewId: 'view-root-id' } }, 100),
  3311 |   ], { databases: [rootDatabase], views: [view('view-root-id', rootDatabase.id)], properties: [...rootProperties.filter(item => item.id !== 'root-date'), date], records: [] })
  3312 |   const createAttempts: Array<{ id: string; type: string }> = []
  3313 |   let releaseFirstPost!: () => void
  3314 |   let signalFirstPost!: () => void
  3315 |   const firstPostStarted = new Promise<void>(resolve => { signalFirstPost = resolve })
  3316 |   const firstPostGate = new Promise<void>(resolve => { releaseFirstPost = resolve })
  3317 |   await page.route(url => url.pathname.endsWith(`/databases/${rootDatabase.id}/views`), async route => {
  3318 |     const request = route.request()
  3319 |     if (request.method() === 'POST') {
  3320 |       createAttempts.push(request.postDataJSON() as { id: string; type: string })
  3321 |       if (createAttempts.length === 2) {
  3322 |         await route.fulfill({ status: 409, contentType: 'application/json', body: JSON.stringify({ statusCode: 409, message: 'View already exists' }) })
  3323 |         return
  3324 |       }
  3325 |       signalFirstPost()
  3326 |       await firstPostGate
  3327 |     }
  3328 |     await route.fallback()
  3329 |   })
  3330 |   await page.goto('/#/app/database-workspace/page/database-page')
  3331 |   const database = page.locator('#database-block-timeline-unknown-block')
  3332 |   await database.getByRole('button', { name: '切换视图' }).click()
  3333 |   await page.getByRole('group', { name: '数据库视图', exact: true }).getByRole('button', { name: '新建时间线视图' }).click()
  3334 |   const dialog = page.getByRole('dialog', { name: '新建时间线视图' })
  3335 |   await page.getByRole('button', { name: '创建时间线' }).click()
  3336 |   await firstPostStarted
  3337 |   expect(createAttempts).toHaveLength(1)
  3338 |   expect(createAttempts[0]?.type).toBe('timeline')
  3339 |   await context.setOffline(true)
  3340 |   await page.evaluate(() => window.dispatchEvent(new Event('offline')))
  3341 |   await expect(dialog).toHaveCount(0)
  3342 |   await context.setOffline(false)
  3343 |   await page.evaluate(() => window.dispatchEvent(new Event('online')))
  3344 |   await database.getByRole('button', { name: '切换视图' }).click()
  3345 |   await page.getByRole('group', { name: '数据库视图', exact: true }).getByRole('button', { name: '新建时间线视图' }).click()
  3346 |   const reopenedDialog = page.getByRole('dialog', { name: '新建时间线视图' })
  3347 |   await expect(page.getByRole('button', { name: '创建时间线' })).toBeEnabled()
  3348 |   releaseFirstPost()
  3349 |   await expect.poll(() => api.views.filter(item => item.type === 'timeline')).toHaveLength(1)
  3350 |   await expect(reopenedDialog).toBeVisible()
  3351 |   await expect(page.getByRole('button', { name: '创建时间线' })).toBeEnabled()
  3352 | 
  3353 |   await page.getByRole('button', { name: '创建时间线' }).click()
  3354 |   await expect(database.getByTestId('database-timeline')).toBeVisible()
  3355 |   expect(createAttempts).toHaveLength(2)
  3356 |   expect(createAttempts[1]?.id).toBe(createAttempts[0]?.id)
  3357 |   expect(createAttempts.map(item => item.type)).toEqual(['timeline', 'timeline'])
  3358 |   expect(api.views.filter(item => item.type === 'timeline')).toHaveLength(1)
```