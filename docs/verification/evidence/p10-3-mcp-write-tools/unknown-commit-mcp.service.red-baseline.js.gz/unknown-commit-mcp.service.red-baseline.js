"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var McpService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.McpService = void 0;
const common_1 = require("@nestjs/common");
const core_1 = require("@nestjs/core");
const server_1 = require("@modelcontextprotocol/server");
const node_1 = require("@modelcontextprotocol/node");
const zod_1 = require("zod");
const workspace_service_1 = require("../server-domain/services/workspace.service");
const page_service_1 = require("../server-domain/services/page.service");
const block_service_1 = require("../server-domain/services/block.service");
const mcp_token_service_1 = require("../server-domain/services/mcp-token.service");
const document_mutation_service_1 = require("../server-domain/services/document-mutation.service");
const database_service_1 = require("../server-domain/services/database.service");
const database_mcp_mutation_service_1 = require("../server-domain/services/database-mcp-mutation.service");
const domain_1 = require("@eotion/domain");
const mcp_database_read_contract_1 = require("./mcp-database-read.contract");
const mcp_database_write_contract_1 = require("./mcp-database-write.contract");
const document_block_codec_1 = require("../server-domain/services/document-block-codec");
const mcp_write_contract_1 = require("./mcp-write.contract");
const mcp_read_contract_1 = require("./mcp-read.contract");
const MCP_TOKEN_PATTERN = /^Bearer +(eotion_mcp_[A-Za-z0-9_-]{43})$/i;
const MCP_REALM = 'Bearer realm="eotion-mcp", error="invalid_token"';
function csvValues(...values) {
    return [...new Set(values.flatMap((value) => value?.split(',') ?? []).map((value) => value.trim()).filter(Boolean))];
}
function configuredProductHosts() {
    return csvValues(process.env.WEB_ORIGIN, process.env.API_ORIGIN)
        .flatMap((origin) => {
        try {
            return [new URL(origin).hostname];
        }
        catch {
            return [];
        }
    });
}
function configuredOriginHosts() {
    return [...new Set(['localhost', '127.0.0.1', '[::1]', ...configuredProductHosts(), ...csvValues(process.env.MCP_ALLOWED_ORIGINS)])];
}
function configuredRequestHosts() {
    return [...new Set(['localhost', '127.0.0.1', '[::1]', ...configuredProductHosts(), ...csvValues(process.env.MCP_ALLOWED_HOSTS)])];
}
let McpService = McpService_1 = class McpService {
    adapterHost;
    tokens;
    workspaces;
    pages;
    blocks;
    documents;
    databases;
    databaseMutations;
    logger = new common_1.Logger(McpService_1.name);
    handler;
    constructor(adapterHost, tokens, workspaces, pages, blocks, documents, databases, databaseMutations) {
        this.adapterHost = adapterHost;
        this.tokens = tokens;
        this.workspaces = workspaces;
        this.pages = pages;
        this.blocks = blocks;
        this.documents = documents;
        this.databases = databases;
        this.databaseMutations = databaseMutations;
    }
    onModuleInit() {
        const handler = (0, server_1.createMcpHandler)(({ authInfo }) => this.createServer(authInfo), {
            responseMode: 'json',
            onerror: () => this.logger.error('MCP request failed'),
        });
        this.handler = handler;
        const fastify = this.adapterHost.httpAdapter.getInstance();
        const handleNodeRequest = (0, node_1.toNodeHandler)({
            fetch: async (request, options) => {
                const response = await handler.fetch(request, options);
                const headers = new Headers(response.headers);
                headers.set('Cache-Control', 'no-store, no-transform');
                return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
            },
        }, {
            onerror: () => this.logger.error('MCP request adapter failed'),
        });
        const validateHost = (0, node_1.hostHeaderValidation)(configuredRequestHosts());
        const validateOrigin = (0, node_1.originValidation)(configuredOriginHosts());
        fastify.all('/mcp', async (request, reply) => {
            reply.hijack();
            reply.raw.setHeader('Cache-Control', 'no-store');
            if (!validateHost(request.raw, reply.raw) || !validateOrigin(request.raw, reply.raw))
                return;
            const sendJson = (statusCode, body, headers = {}) => {
                reply.raw.statusCode = statusCode;
                reply.raw.setHeader('Content-Type', 'application/json; charset=utf-8');
                for (const [name, value] of Object.entries(headers))
                    reply.raw.setHeader(name, value);
                reply.raw.end(JSON.stringify(body));
            };
            const authorization = request.headers.authorization;
            const match = typeof authorization === 'string' ? MCP_TOKEN_PATTERN.exec(authorization) : null;
            if (!match) {
                sendJson(401, { error: 'Authentication required' }, { 'WWW-Authenticate': MCP_REALM });
                return;
            }
            let identity;
            try {
                identity = await this.tokens.resolve(match[1]);
            }
            catch {
                this.logger.error('MCP token lookup failed');
                sendJson(500, { error: 'Internal server error' });
                return;
            }
            if (!identity) {
                sendJson(401, { error: 'Authentication required' }, { 'WWW-Authenticate': MCP_REALM });
                return;
            }
            const rawRequest = request.raw;
            rawRequest.auth = {
                token: '',
                clientId: 'eotion-mcp',
                scopes: [],
                extra: { userId: identity.userId },
            };
            try {
                await handleNodeRequest(rawRequest, reply.raw, request.body);
            }
            catch {
                this.logger.error('MCP request handling failed');
                if (!reply.raw.headersSent)
                    sendJson(500, { error: 'Internal server error' });
            }
        });
    }
    async onModuleDestroy() {
        await this.handler?.close();
    }
    createServer(authInfo) {
        const userId = authInfo?.extra?.userId;
        const server = new server_1.McpServer({ name: 'eotion', version: '0.0.1' });
        server.registerTool('eotion_list_workspaces', {
            title: 'List workspaces',
            description: 'List the authenticated user’s workspaces.',
            inputSchema: zod_1.z.strictObject({}),
            outputSchema: zod_1.z.object({
                workspaces: zod_1.z.array(zod_1.z.object({ id: zod_1.z.string(), name: zod_1.z.string() })),
            }),
            annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
        }, async () => {
            try {
                if (typeof userId !== 'string')
                    throw new Error('Missing authenticated user');
                const listed = await this.workspaces.listByOwner(userId);
                const result = {
                    workspaces: listed.map(({ id, name }) => ({ id, name })),
                };
                (0, mcp_read_contract_1.assertMcpResultSize)(result);
                return {
                    structuredContent: result,
                    content: [{ type: 'text', text: JSON.stringify(result) }],
                };
            }
            catch {
                return {
                    isError: true,
                    content: [{ type: 'text', text: 'Unable to list workspaces.' }],
                };
            }
        });
        const registerPageListTool = (name, search) => {
            server.registerTool(name, {
                title: search ? 'Search pages' : 'List pages',
                description: search
                    ? 'Search accessible page titles in the specified Eotion workspace using a case-insensitive literal substring.'
                    : 'List pages in an accessible workspace in ascending page ID order.',
                inputSchema: search ? mcp_read_contract_1.SearchPagesInputSchema : mcp_read_contract_1.ListPagesInputSchema,
                outputSchema: mcp_read_contract_1.ListPagesOutputSchema,
                annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
            }, async (input) => {
                try {
                    if (typeof userId !== 'string')
                        throw new Error('Missing authenticated user');
                    const query = search && 'query' in input && typeof input.query === 'string' ? input.query : undefined;
                    const listed = await this.pages.listWindow(userId, input.workspaceId, {
                        ...(input.cursor === undefined ? {} : { cursor: input.cursor }),
                        limit: input.limit,
                        ...(query === undefined ? {} : { query }),
                    });
                    const result = (0, mcp_read_contract_1.assertMcpResultSize)({
                        items: listed.items.map(mcp_read_contract_1.toMcpPageSummary),
                        nextCursor: listed.nextCursor,
                    });
                    return { structuredContent: result, content: [{ type: 'text', text: JSON.stringify(result) }] };
                }
                catch {
                    return { isError: true, content: [{ type: 'text', text: search ? 'Unable to search pages.' : 'Unable to list pages.' }] };
                }
            });
        };
        registerPageListTool('eotion_list_pages', false);
        registerPageListTool('eotion_search_pages', true);
        const databaseReadError = (error) => {
            const code = error instanceof Error && (/MCP result too large|exceeds (?:the )?maximum|exceeded its maximum size/i.test(error.message))
                ? 'LIMIT_EXCEEDED'
                : error instanceof common_1.BadRequestException
                    ? 'INVALID_ARGUMENT'
                    : error instanceof common_1.NotFoundException || error instanceof common_1.ForbiddenException
                        ? 'NOT_FOUND'
                        : error instanceof common_1.ConflictException
                            ? 'CONFLICT'
                            : error instanceof common_1.ServiceUnavailableException
                                ? 'UNAVAILABLE'
                                : 'INTERNAL';
            const messages = {
                INVALID_ARGUMENT: 'Invalid arguments.',
                NOT_FOUND: 'Resource not found.',
                CONFLICT: 'Resource changed; reload and retry.',
                UNAVAILABLE: 'Temporarily unavailable.',
                LIMIT_EXCEEDED: 'The response exceeds the supported size limit.',
                INTERNAL: 'Unable to complete the request.',
            };
            return { isError: true, content: [{ type: 'text', text: `${code}: ${messages[code]}` }] };
        };
        const toDatabaseSummary = (database) => ({
            id: database.id, workspaceId: database.workspaceId, name: database.name, version: database.version,
            createdAt: database.createdAt, updatedAt: database.updatedAt,
        });
        const toDatabaseProperty = (property) => ({
            id: property.id, databaseId: property.databaseId, workspaceId: property.workspaceId, name: property.name,
            type: property.type, version: property.version, createdAt: property.createdAt, updatedAt: property.updatedAt,
            ...(property.options === undefined ? {} : { options: property.options }),
            ...(property.config === undefined ? {} : { config: property.config }),
        });
        const toDatabaseView = (view) => ({
            id: view.id, databaseId: view.databaseId, workspaceId: view.workspaceId, name: view.name, type: view.type,
            version: view.version, createdAt: view.createdAt, updatedAt: view.updatedAt,
            ...(view.config === undefined ? {} : { config: view.config }),
        });
        const toDatabaseRecord = (record, propertyIds) => ({
            id: record.id, databaseId: record.databaseId, workspaceId: record.workspaceId, pageId: record.pageId,
            properties: Object.fromEntries(Object.entries(record.properties).filter(([propertyId]) => propertyIds === undefined || propertyIds.has(propertyId))),
            version: record.version, createdAt: record.createdAt, updatedAt: record.updatedAt, pageVersion: record.pageVersion,
        });
        server.registerTool('eotion_list_databases', {
            title: 'List databases',
            description: 'List databases in an accessible Eotion workspace using a bounded cursor window.',
            inputSchema: mcp_database_read_contract_1.McpListDatabasesInputSchema,
            outputSchema: mcp_database_read_contract_1.McpListDatabasesOutputSchema,
            annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
        }, async (input) => {
            try {
                if (typeof userId !== 'string')
                    throw new Error('Missing authenticated user');
                const listed = await this.databases.listWindow(userId, input.workspaceId, {
                    ...(input.cursor === undefined ? {} : { cursor: input.cursor }),
                    limit: input.limit,
                });
                const result = (0, mcp_read_contract_1.assertMcpResultSize)(mcp_database_read_contract_1.McpListDatabasesOutputSchema.parse({
                    items: listed.items.map(toDatabaseSummary),
                    nextCursor: listed.nextCursor,
                }));
                return { structuredContent: result, content: [{ type: 'text', text: JSON.stringify(result) }] };
            }
            catch (error) {
                return databaseReadError(error);
            }
        });
        server.registerTool('eotion_get_database_schema', {
            title: 'Get database schema',
            description: 'Read the database, its properties and all supported views. Includes the currently supported view types and temporary query capabilities.',
            inputSchema: mcp_database_read_contract_1.McpGetDatabaseSchemaInputSchema,
            outputSchema: mcp_database_read_contract_1.McpGetDatabaseSchemaOutputSchema,
            annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
        }, async (input) => {
            try {
                if (typeof userId !== 'string')
                    throw new Error('Missing authenticated user');
                const schema = await this.databases.getSchema(userId, input.workspaceId, input.databaseId);
                const result = (0, mcp_read_contract_1.assertMcpResultSize)(mcp_database_read_contract_1.McpGetDatabaseSchemaOutputSchema.parse({
                    database: toDatabaseSummary(schema.database),
                    properties: schema.properties.map(toDatabaseProperty),
                    views: schema.views.map(toDatabaseView),
                    capabilities: { viewTypes: [...domain_1.DATABASE_VIEW_TYPES], supportsTemporaryFiltersAndSorts: true },
                }));
                return { structuredContent: result, content: [{ type: 'text', text: JSON.stringify(result) }] };
            }
            catch (error) {
                return databaseReadError(error);
            }
        });
        server.registerTool('eotion_query_database', {
            title: 'Query database',
            description: 'Query a saved database view with server-side filters, sorting and cursor pagination. Supplied filters or sorts replace only that saved configuration for this call; omitted values keep the saved configuration. Temporary settings never update the saved view. Repeat the same overrides when requesting the next cursor page.',
            inputSchema: mcp_database_read_contract_1.McpQueryDatabaseInputSchema,
            outputSchema: mcp_database_read_contract_1.McpQueryDatabaseOutputSchema,
            annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
        }, async (input) => {
            try {
                if (typeof userId !== 'string')
                    throw new Error('Missing authenticated user');
                const response = await this.databases.getViewRecords(userId, input.workspaceId, input.databaseId, input.viewId, {
                    ...(input.cursor === undefined ? {} : { cursor: input.cursor }),
                    limit: input.limit,
                    ...(input.filters === undefined ? {} : { filters: input.filters }),
                    ...(input.sorts === undefined ? {} : { sorts: input.sorts }),
                    ...(input.propertyIds === undefined ? {} : { propertyIds: input.propertyIds }),
                });
                const titleProperty = response.properties.find(property => property.type === 'title');
                if (!titleProperty)
                    throw new common_1.ConflictException('Database title property is missing');
                const requestedIds = input.propertyIds === undefined
                    ? response.properties.map(property => property.id)
                    : [...new Set([...input.propertyIds, titleProperty.id])];
                const requestedSet = new Set(requestedIds);
                const properties = response.properties.filter(property => requestedSet.has(property.id)).map(toDatabaseProperty);
                const savedConfig = response.view.config ?? { filters: [], sorts: [], visibleProperties: null, propertyOrder: null };
                const result = (0, mcp_read_contract_1.assertMcpResultSize)(mcp_database_read_contract_1.McpQueryDatabaseOutputSchema.parse({
                    database: toDatabaseSummary(response.database),
                    view: toDatabaseView(response.view),
                    properties,
                    records: response.records.map(record => toDatabaseRecord(record, requestedSet)),
                    nextCursor: response.nextCursor,
                    effectiveQuery: {
                        filters: input.filters ?? savedConfig.filters,
                        sorts: input.sorts ?? savedConfig.sorts,
                        propertyIds: properties.map(property => property.id),
                    },
                }));
                return { structuredContent: result, content: [{ type: 'text', text: JSON.stringify(result) }] };
            }
            catch (error) {
                return databaseReadError(error);
            }
        });
        server.registerTool('eotion_get_record', {
            title: 'Get database record',
            description: 'Read one record in the specified accessible database, including its canonical Page title and derived values when supported.',
            inputSchema: mcp_database_read_contract_1.McpGetRecordInputSchema,
            outputSchema: mcp_database_read_contract_1.McpGetRecordOutputSchema,
            annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
        }, async (input) => {
            try {
                if (typeof userId !== 'string')
                    throw new Error('Missing authenticated user');
                const record = await this.databases.getRecord(userId, input.workspaceId, input.databaseId, input.recordId);
                const result = (0, mcp_read_contract_1.assertMcpResultSize)(mcp_database_read_contract_1.McpGetRecordOutputSchema.parse(toDatabaseRecord(record)));
                return { structuredContent: result, content: [{ type: 'text', text: JSON.stringify(result) }] };
            }
            catch (error) {
                return databaseReadError(error);
            }
        });
        server.registerTool('eotion_resolve_relation_records', {
            title: 'Resolve relation records',
            description: 'Search for relation candidates or resolve known record ids to stable record/page ids and titles within an accessible workspace database.',
            inputSchema: mcp_database_read_contract_1.McpResolveRelationRecordsInputSchema,
            outputSchema: mcp_database_read_contract_1.McpResolveRelationRecordsOutputSchema,
            annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
        }, async (input) => {
            try {
                if (typeof userId !== 'string')
                    throw new Error('Missing authenticated user');
                const result = input.mode === 'search'
                    ? await this.databases.listRecordOptions(userId, input.workspaceId, input.databaseId, {
                        ...(input.search === undefined ? {} : { search: input.search }),
                        ...(input.cursor === undefined ? {} : { cursor: input.cursor }),
                        limit: input.limit,
                    })
                    : { ...(await this.databases.resolveRecordOptions(userId, input.workspaceId, input.databaseId, { recordIds: input.recordIds })), nextCursor: null };
                const safe = (0, mcp_read_contract_1.assertMcpResultSize)(mcp_database_read_contract_1.McpResolveRelationRecordsOutputSchema.parse(result));
                return { structuredContent: safe, content: [{ type: 'text', text: JSON.stringify(safe) }] };
            }
            catch (error) {
                return databaseReadError(error);
            }
        });
        const databaseWriteError = (error) => {
            const message = error instanceof Error ? error.message : '';
            const code = /MCP (?:write payload|result) too large|exceeds (?:the )?maximum|exceeded its maximum size/i.test(message)
                ? 'LIMIT_EXCEEDED'
                : error instanceof common_1.BadRequestException
                    ? 'INVALID_ARGUMENT'
                    : error instanceof common_1.NotFoundException || error instanceof common_1.ForbiddenException
                        ? 'NOT_FOUND'
                        : error instanceof common_1.ConflictException
                            ? 'CONFLICT'
                            : error instanceof common_1.ServiceUnavailableException
                                ? 'UNAVAILABLE'
                                : 'INTERNAL';
            const response = code === 'UNAVAILABLE'
                ? /unconfirmed/i.test(message)
                    ? 'The commit result is unconfirmed. Retry only with the original idempotencyKey and identical payload, or read the resource state.'
                    : 'Database writes require MongoDB replica set or mongos transactions.'
                : code === 'LIMIT_EXCEEDED'
                    ? 'The request or result exceeds the supported size limit.'
                    : code === 'CONFLICT'
                        ? 'Resource changed; reload and retry.'
                        : code === 'NOT_FOUND'
                            ? 'Resource not found.'
                            : code === 'INVALID_ARGUMENT'
                                ? 'Invalid arguments.'
                                : 'Unable to complete the request.';
            return { isError: true, content: [{ type: 'text', text: `${code}: ${response}` }] };
        };
        server.registerTool('eotion_create_record', {
            title: 'Create database record',
            description: 'Read the database schema and latest database version first. Creates one record with title and optional initial properties. New entity IDs are generated by Eotion. Repeat the identical payload with the same idempotencyKey to replay the original result. This tool does not batch writes or promise View scheduling.',
            inputSchema: mcp_database_write_contract_1.McpCreateRecordInputSchema,
            outputSchema: mcp_database_write_contract_1.McpCreateRecordOutputSchema,
            annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true, openWorldHint: false },
        }, async (input) => {
            try {
                if (typeof userId !== 'string')
                    throw new Error('Missing authenticated user');
                (0, mcp_write_contract_1.assertMcpWritePayloadSize)(input);
                const result = await this.databaseMutations.createRecord(userId, input, ({ database, record }) => (0, mcp_read_contract_1.assertMcpResultSize)(mcp_database_write_contract_1.McpCreateRecordOutputSchema.parse({ database: toDatabaseSummary(database), record: toDatabaseRecord(record) })));
                return { structuredContent: result, content: [{ type: 'text', text: JSON.stringify(result) }] };
            }
            catch (error) {
                return databaseWriteError(error);
            }
        });
        server.registerTool('eotion_update_record_cell', {
            title: 'Update database record cell',
            description: 'Read the database schema and current record/database versions first. The supplied value replaces the complete cell value; null clears nullable values and Relation values use an empty array. Repeat the identical payload with the same idempotencyKey to replay the original result. This tool does not batch writes, convert property types, or promise View scheduling.',
            inputSchema: mcp_database_write_contract_1.McpUpdateRecordCellInputSchema,
            outputSchema: mcp_database_write_contract_1.McpUpdateRecordCellOutputSchema,
            annotations: { readOnlyHint: false, destructiveHint: true, idempotentHint: true, openWorldHint: false },
        }, async (input) => {
            try {
                if (typeof userId !== 'string')
                    throw new Error('Missing authenticated user');
                (0, mcp_write_contract_1.assertMcpWritePayloadSize)(input);
                const result = await this.databaseMutations.updateRecordCell(userId, input, ({ database, record }) => (0, mcp_read_contract_1.assertMcpResultSize)(mcp_database_write_contract_1.McpUpdateRecordCellOutputSchema.parse({ database: toDatabaseSummary(database), record: toDatabaseRecord(record) })));
                return { structuredContent: result, content: [{ type: 'text', text: JSON.stringify(result) }] };
            }
            catch (error) {
                return databaseWriteError(error);
            }
        });
        server.registerTool('eotion_create_property', {
            title: 'Create database property',
            description: 'Read the database schema and latest database version first. Creates one property; Select options may include caller-defined business IDs. Eotion generates the new property ID. Repeat the identical payload with the same idempotencyKey to replay the original result. This tool does not batch writes, convert property types, or promise View scheduling.',
            inputSchema: mcp_database_write_contract_1.McpCreatePropertyInputSchema,
            outputSchema: mcp_database_write_contract_1.McpCreatePropertyOutputSchema,
            annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true, openWorldHint: false },
        }, async (input) => {
            try {
                if (typeof userId !== 'string')
                    throw new Error('Missing authenticated user');
                (0, mcp_write_contract_1.assertMcpWritePayloadSize)(input);
                const result = await this.databaseMutations.createProperty(userId, input, ({ database, property }) => (0, mcp_read_contract_1.assertMcpResultSize)(mcp_database_write_contract_1.McpCreatePropertyOutputSchema.parse({ database: toDatabaseSummary(database), property: toDatabaseProperty(property) })));
                return { structuredContent: result, content: [{ type: 'text', text: JSON.stringify(result) }] };
            }
            catch (error) {
                return databaseWriteError(error);
            }
        });
        server.registerTool('eotion_update_property', {
            title: 'Update database property',
            description: 'Read the database schema and current database/property versions first. Supplied name, options, and config each replace that complete field; omitted fields are preserved. Include options when replacing Select options and config when replacing a property configuration. Repeat the identical payload with the same idempotencyKey to replay the original result. Type conversion and View scheduling are not supported.',
            inputSchema: mcp_database_write_contract_1.McpUpdatePropertyInputSchema,
            outputSchema: mcp_database_write_contract_1.McpUpdatePropertyOutputSchema,
            annotations: { readOnlyHint: false, destructiveHint: true, idempotentHint: true, openWorldHint: false },
        }, async (input) => {
            try {
                if (typeof userId !== 'string')
                    throw new Error('Missing authenticated user');
                (0, mcp_write_contract_1.assertMcpWritePayloadSize)(input);
                const result = await this.databaseMutations.updateProperty(userId, input, ({ database, property }) => (0, mcp_read_contract_1.assertMcpResultSize)(mcp_database_write_contract_1.McpUpdatePropertyOutputSchema.parse({ database: toDatabaseSummary(database), property: toDatabaseProperty(property) })));
                return { structuredContent: result, content: [{ type: 'text', text: JSON.stringify(result) }] };
            }
            catch (error) {
                return databaseWriteError(error);
            }
        });
        server.registerTool('eotion_create_view', {
            title: 'Create database view',
            description: 'Read the database schema and latest database version first. Creates one view; config, when supplied, is the complete saved configuration and options preserves extension data. Eotion generates the new view ID. Repeat the identical payload with the same idempotencyKey to replay the original result. This tool does not batch writes or promise View scheduling.',
            inputSchema: mcp_database_write_contract_1.McpCreateViewInputSchema,
            outputSchema: mcp_database_write_contract_1.McpCreateViewOutputSchema,
            annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true, openWorldHint: false },
        }, async (input) => {
            try {
                if (typeof userId !== 'string')
                    throw new Error('Missing authenticated user');
                (0, mcp_write_contract_1.assertMcpWritePayloadSize)(input);
                const result = await this.databaseMutations.createView(userId, input, ({ database, view }) => (0, mcp_read_contract_1.assertMcpResultSize)(mcp_database_write_contract_1.McpCreateViewOutputSchema.parse({ database: toDatabaseSummary(database), view: toDatabaseView(view) })));
                return { structuredContent: result, content: [{ type: 'text', text: JSON.stringify(result) }] };
            }
            catch (error) {
                return databaseWriteError(error);
            }
        });
        server.registerTool('eotion_update_view', {
            title: 'Update database view',
            description: 'Read the database schema and current database/view versions first. Supplied name and config replace those complete fields; omitted fields are preserved. A config replacement must include filters, sorts, visibleProperties, and propertyOrder, and must carry forward any options extensions to retain them. Type conversion and View scheduling are not supported. Repeat the identical payload with the same idempotencyKey to replay the original result.',
            inputSchema: mcp_database_write_contract_1.McpUpdateViewInputSchema,
            outputSchema: mcp_database_write_contract_1.McpUpdateViewOutputSchema,
            annotations: { readOnlyHint: false, destructiveHint: true, idempotentHint: true, openWorldHint: false },
        }, async (input) => {
            try {
                if (typeof userId !== 'string')
                    throw new Error('Missing authenticated user');
                (0, mcp_write_contract_1.assertMcpWritePayloadSize)(input);
                const result = await this.databaseMutations.updateView(userId, input, ({ database, view }) => (0, mcp_read_contract_1.assertMcpResultSize)(mcp_database_write_contract_1.McpUpdateViewOutputSchema.parse({ database: toDatabaseSummary(database), view: toDatabaseView(view) })));
                return { structuredContent: result, content: [{ type: 'text', text: JSON.stringify(result) }] };
            }
            catch (error) {
                return databaseWriteError(error);
            }
        });
        server.registerTool('eotion_rename_database', {
            title: 'Rename database',
            description: 'Read the database and latest version first. Replaces the database name. Repeat the identical payload with the same idempotencyKey to replay the original result.',
            inputSchema: mcp_database_write_contract_1.McpRenameDatabaseInputSchema,
            outputSchema: mcp_database_write_contract_1.McpRenameDatabaseOutputSchema,
            annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true, openWorldHint: false },
        }, async (input) => {
            try {
                if (typeof userId !== 'string')
                    throw new Error('Missing authenticated user');
                (0, mcp_write_contract_1.assertMcpWritePayloadSize)(input);
                const result = await this.databaseMutations.renameDatabase(userId, input, ({ database }) => (0, mcp_read_contract_1.assertMcpResultSize)(mcp_database_write_contract_1.McpRenameDatabaseOutputSchema.parse({ database: toDatabaseSummary(database) })));
                return { structuredContent: result, content: [{ type: 'text', text: JSON.stringify(result) }] };
            }
            catch (error) {
                return databaseWriteError(error);
            }
        });
        server.registerTool('eotion_get_page', {
            title: 'Get page',
            description: 'Read an accessible page summary and its supported body blocks.',
            inputSchema: mcp_read_contract_1.GetPageInputSchema,
            outputSchema: mcp_read_contract_1.GetPageOutputSchema,
            annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
        }, async (input) => {
            try {
                if (typeof userId !== 'string')
                    throw new Error('Missing authenticated user');
                const page = await this.pages.findAccessible(userId, input.pageId);
                if (!page)
                    throw new Error('Page not found');
                const records = await this.blocks.listBounded(userId, page.workspaceId, page.id, 1000);
                const result = (0, mcp_read_contract_1.assertMcpResultSize)({ ...(0, mcp_read_contract_1.toMcpPageSummary)(page), blocks: (0, mcp_read_contract_1.toMcpBlocks)(records) });
                return { structuredContent: result, content: [{ type: 'text', text: JSON.stringify(result) }] };
            }
            catch {
                return { isError: true, content: [{ type: 'text', text: 'Unable to get page.' }] };
            }
        });
        const projectPage = (page, records) => (0, mcp_read_contract_1.assertMcpResultSize)(mcp_read_contract_1.GetPageOutputSchema.parse({ ...(0, mcp_read_contract_1.toMcpPageSummary)(page), blocks: (0, mcp_read_contract_1.toMcpBlocks)(records) }));
        const writeError = (error) => ({
            isError: true,
            content: [{ type: 'text', text: error instanceof common_1.ConflictException
                        ? error.message
                        : error instanceof common_1.ServiceUnavailableException
                            ? 'Page writes require MongoDB replica set transactions.'
                            : 'Unable to write page.' }],
        });
        server.registerTool('eotion_create_page', {
            title: 'Create page',
            description: 'Create a new page in a writable Eotion workspace with an initial document body. Use a unique idempotencyKey; repeat identical requests safely.',
            inputSchema: mcp_write_contract_1.CreatePageInputSchema,
            outputSchema: mcp_read_contract_1.GetPageOutputSchema,
            annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true, openWorldHint: false },
        }, async (input) => {
            try {
                if (typeof userId !== 'string')
                    throw new Error('Missing authenticated user');
                (0, mcp_write_contract_1.assertMcpWritePayloadSize)(input);
                const result = await this.documents.create(userId, { ...input, blocks: (0, document_block_codec_1.toDocumentBlocks)(input.blocks) }, projectPage, input);
                return { structuredContent: result, content: [{ type: 'text', text: JSON.stringify(result) }] };
            }
            catch (error) {
                return writeError(error);
            }
        });
        server.registerTool('eotion_update_page', {
            title: 'Update page',
            description: 'Read the page with eotion_get_page first, then update using its latest updatedAt as expectedUpdatedAt. Supplied blocks are the complete target body snapshot; omitted blocks preserve the body. Repeat identical requests with the same idempotencyKey safely.',
            inputSchema: mcp_write_contract_1.UpdatePageInputSchema,
            outputSchema: mcp_read_contract_1.GetPageOutputSchema,
            annotations: { readOnlyHint: false, destructiveHint: true, idempotentHint: true, openWorldHint: false },
        }, async (input) => {
            try {
                if (typeof userId !== 'string')
                    throw new Error('Missing authenticated user');
                (0, mcp_write_contract_1.assertMcpWritePayloadSize)(input);
                const { blocks, ...patch } = input;
                const result = await this.documents.update(userId, {
                    ...patch,
                    ...(blocks === undefined ? {} : { blocks: (0, document_block_codec_1.toDocumentBlocks)(blocks) }),
                }, projectPage, input);
                return { structuredContent: result, content: [{ type: 'text', text: JSON.stringify(result) }] };
            }
            catch (error) {
                return writeError(error);
            }
        });
        return server;
    }
};
exports.McpService = McpService;
exports.McpService = McpService = McpService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [core_1.HttpAdapterHost,
        mcp_token_service_1.McpTokenService,
        workspace_service_1.WorkspaceService,
        page_service_1.PageService,
        block_service_1.BlockService,
        document_mutation_service_1.DocumentMutationService,
        database_service_1.DatabaseService,
        database_mcp_mutation_service_1.DatabaseMcpMutationService])
], McpService);
//# sourceMappingURL=mcp.service.js.map